import { createBrowserRouter, createRoutesFromElements, RouterProvider, Route } from "react-router-dom";

import Home from "../views/Home";


const router = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route element={<Protected />}>
        <Route path="/" element={<Home />} />
      </Route>
    </>
  )
);

const Index = () => {
  return <RouterProvider router={router} />;
};

export default Index;
