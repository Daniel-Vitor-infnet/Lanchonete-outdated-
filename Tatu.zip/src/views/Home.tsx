import { IconButton, Avatar, Button, Grid2, Box, Typography, CardNewItem, CustomList } from "../components";
import SignalCellularAltIcon from '@mui/icons-material/SignalCellularAlt';
import SettingsIcon from '@mui/icons-material/Settings';
import { Link, useNavigate, Navigate } from 'react-router-dom';
import { ACTIONS } from '../components/constants/actions'
import { useEffect, useState } from 'react';
import { useAppContext } from "../Context";
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';




const Home: React.FC = () => {
  const navigate = useNavigate();

  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    ...theme.applyStyles('dark', {
      backgroundColor: '#1A2027',
    }),
  }));



  return (
    
    <Box sx={{ width: '100%' }}>
      <Grid2 container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
        <Grid2 size={6}>
          <Item>1</Item>
        </Grid2>
        <Grid2 size={6}>
          <Item>2</Item>
        </Grid2>
        <Grid2 size={6}>
          <Item>3</Item>
        </Grid2>
        <Grid2 size={6}>
          <Item>4</Item>
        </Grid2>
      </Grid2>
    </Box>
  );
};





export default Home;
